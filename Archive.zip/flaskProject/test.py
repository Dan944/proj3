import telnetlib
import time

HOST = "10.136.70.10"
PORT = 50000



tn = telnetlib.Telnet(host=HOST, port=PORT, timeout=10)
# tn.interact()
tn.read_until(b"username (guest): ", timeout=0.5)
tn.write(b'a\n\n')
time.sleep(0.1)
tn.read_until(b"password: ", timeout=0.5)
tn.write(b'a\n\n')
time.sleep(0.5)
print(tn.read_very_eager().decode('utf8'))
time.sleep(0.5)
# while(True):
#     info = input()
#     tn.write(info.encode('ascii') + b'\n\n')
#     time.sleep(0.1)
#     print(tn.read_very_eager().decode('utf8'))

tn.write(b"exit\n")
print("exit")

if __name__ == "__main__":
    pass