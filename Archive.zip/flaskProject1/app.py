from flask import Flask, render_template, request, jsonify
from telnetlib import Telnet
import time

from werkzeug.debug import console

app = Flask(__name__)

host = "10.136.70.10"
port = 50001
tn = Telnet(host, port)

welstr = "********************************************************************\
You are attempting to log into online tic-tac-toe Server.\
Please be advised by continuing that you agree to the terms of the\
Computer Access and Usage Policy of online tic-tac-toe Server.\
\
********************************************************************\
\
\
username(guest):"

output = welstr
board_data = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]


def telnet_connection(command):
    tn.write((command + '\n\n').encode('utf-8'))  # 发送命令给 Telnet 服务器
    # telnet_result = tn.read_until(b'username(guest):\n', timeout=5).decode('utf-8')  # 读取 Telnet 服务器的输出
    time.sleep(0.5)
    # telnet_result = tn.read_very_eager().decode('utf8')
    # return telnet_result


@app.route('/')
def index():
    return render_template('index.html', result=welstr)


def check_board(str):
    count = 0
    for line in str.strip().split('\n'):
        if line[:7] == "  1 2 3":
            return count
        count += 1
    return 0


def parse_board(board_str, count):
    global board_data
    lines = board_str.strip().split('\n')
    board_info = lines[count + 1:count + 4]
    for i in range(3):
        words = board_info[i].split(" ")
        for j in range(3):
            word = words[j + 1]
            if word == "X":
                board_data[i][j] = 1
            elif word == "O":
                board_data[i][j] = 2
            else:
                board_data[i][j] = 0


@app.route('/get_output')
def get_output():
    global output, board_data
    temp_telnet_result = tn.read_very_eager().decode('utf8')
    if temp_telnet_result != "":
        count = check_board(temp_telnet_result)
        output = temp_telnet_result
        if count > 0:
            print("Found board data")
            parse_board(temp_telnet_result, count)
            # output = '\n'.join(str(board_data))

    return jsonify({'output': output, 'board_data': board_data})


@app.route('/make_move', methods=['POST'])
def make_move():
    data = request.json
    move = data['move']
    print("Received move:", move)
    telnet_connection(move)
    return jsonify({'status': 'success', 'move': move})


@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        command = request.form['command']
        print(command)
        # telnet_result = telnet_connection(command)
        # return render_template('index.html', command=command, output=output, result=telnet_result)
        telnet_connection(command)
        return render_template('index.html', command=command, output=output, board_data=board_data)


if __name__ == '__main__':
    app.run(debug=True, port = 7777)
